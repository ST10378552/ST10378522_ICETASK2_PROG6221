﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10378552_IceTask2
{
    internal class InputValidator
    {
        public static bool ValidateItem(InventoryItem item)
        {
            // Add your validation logic here
            return true; // For now, just return true
        }
    }

    public static class ErrorHandler
    {
        public static void HandleError(Exception ex)
        {
            // Handle error, for now, just print to console
            Console.WriteLine($"An error occurred: {ex.Message}");
        }
}
