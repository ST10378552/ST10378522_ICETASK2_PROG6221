﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10378552_IceTask2
{
    internal class Inventory
    {
        private Dictionary<string, List<InventoryItem>> inventoryItems;

        public Inventory()
        {
            inventoryItems = new Dictionary<string, List<InventoryItem>>();
        }

        public void AddItem(InventoryItem item)
        {
            if (!inventoryItems.ContainsKey(item.Category))
            {
                inventoryItems[item.Category] = new List<InventoryItem>();
            }

            inventoryItems[item.Category].Add(item);
        }

        public void RemoveItem(InventoryItem item)
        {
            if (inventoryItems.ContainsKey(item.Category))
            {
                inventoryItems[item.Category].Remove(item);
            }
        }

        public void DisplayInventory()
        {
            foreach (var category in inventoryItems.Keys)
            {
                Console.WriteLine($"Category: {category}");
                foreach (var item in inventoryItems[category])
                {
                    Console.WriteLine($"Name: {item.Name}, Price: {item.Price}, Quantity: {item.Quantity}");
                }
                Console.WriteLine();
            }
        }
}
