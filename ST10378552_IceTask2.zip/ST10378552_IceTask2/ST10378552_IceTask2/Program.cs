﻿// See https://aka.ms/new-console-template for more information
using ST10378552_IceTask2;

class Program
{
    static void Main(string[] args)
    {
        // Testing the classes
        InventoryItem item1 = new InventoryItem { Name = "Apple", Price = 1.99m, Quantity = 10, Category = "Fruits" };
        InventoryItem item2 = new InventoryItem { Name = "Tomato", Price = 0.75m, Quantity = 20, Category = "Vegetables" };

        Inventory inventory = new Inventory();
        inventory.AddItem(item1);
        inventory.AddItem(item2);

        inventory.DisplayInventory();
    }
}
